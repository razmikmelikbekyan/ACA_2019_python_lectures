# import sys
#
# print(sys.path)
# from pathlib import Path

# sys.path.insert(0, str(Path(__file__).parent))
# print(sys.path)
#
from helpers.checkers import *
from helpers.utils.math_tools import *

print('I am helpers init')

# __all__ = ["check_input", "square"]
